class CfgVehicles {
	class Man;
	class CAManBase: Man {
		class ACE_SelfActions {
			class ACE_Equipment {
				class ace_overheating_UnJam {
					condition = "!RAA_misc_hideACEUnjamming && ace_overheating_enabled && {[_player] call ACE_overheating_fnc_canUnjam}";
				};
				
				class RAA_camoFace_paint {
					displayName = "Apply face camouflage paint";
					condition = "[ACE_player] call RAA_misc_fnc_facepaint_canApply";
				//    exceptions[] = {};
					statement = "[player, 'ace_field_rations_drinkFromSourceHigh', 1] call ace_common_fnc_doAnimation; [11, [], {[player] call RAA_misc_fnc_facepaint}, {}, 'Applying Face Paint'] call ace_common_fnc_progressBar";
				//	icon = QPATHTOF(pics\facepaint_icon);
					icon = QPATHTOF(pics\facepaint_icon);
				};
				class RAA_camoFace_remove {
					displayName = "Wash away face camouflage paint";
					condition = "(face player) == player getVariable ['RAA_misc_facepaint_faces', []] select 1";
				//    exceptions[] = {};
					statement = "[player, 'ace_field_rations_drinkFromSourceHigh', 1] call ace_common_fnc_doAnimation; [11, [], {[player] call RAA_misc_fnc_facepaint}, {}, 'Washing off Face Paint'] call ace_common_fnc_progressBar";
					icon = QPATHTOF(pics\facepaint_icon);
				};
				
				
				class RAA_chopDownTree {
					displayName = "Chop down a tree";
				//	condition = "[player, false] call FUNC(canChopDownTree)";
					condition = QUOTE([player, false] call FUNC(canChopDownTree));
				//    exceptions[] = {};
				//	statement = "[player, false] call FUNC(DoChopDownTree)";
					statement = QUOTE([ARR_2(player, false)] call FUNC(action_chopDownTree));
					icon = QPATHTOF(pics\icon_cutting_tree);
				};
				
				class RAA_delimbTree {
					displayName = "delimb a tree";
				//	condition = "[player, true] call FUNC(canChopDownTree)";
					condition = QUOTE([player, true]call FUNC(canChopDownTree));
				//    exceptions[] = {};
				//	statement = "[player, true] call FUNC(DoChopDownTree)";
					statement = QUOTE([ARR_2(player, true)] call FUNC(action_chopDownTree));
					icon = QPATHTOF(pics\icon_cutting_tree);
				};
				
				
				
				
				
				
				
				class RAA_beltSlot {
						displayName = "Belt Slots";
						condition = "true";
						statement = "";
					//	showDisabled = 0;
					//	exceptions[] = {"isNotInside", "isNotSwimming", "isNotSitting"};
						exceptions[] = {};
						icon = QPATHTOF(pics\icon_belt.paa);
					
					class RAA_beltSlot_moveToBelt {
						displayName = "Move item to belt";
						condition = "call RAA_misc_fnc_beltSlot_canMoveToBelt";
					//    exceptions[] = {};
						statement = "";
					//	icon = QPATHTOF(pics\icon_cutting_tree);
						insertChildren = "call RAA_misc_fnc_beltSlot_getChildrens";
						
					};
					
					class RAA_beltSlot_moveFromBelt1 {
						displayName = "Move %1 to inventory";
						condition = "0 call RAA_misc_fnc_beltSlot_canMoveFrombelt";
					//    exceptions[] = {};
						statement = "0 call RAA_misc_fnc_beltSlot_doMoveFrombelt";
						icon = "";
						modifierFunction = "[_this, 0] call RAA_misc_fnc_beltSlot_actionModifier";
					};
					
					class RAA_beltSlot_moveFromBelt2 {
						displayName = "Move %1 to inventory";
						condition = "1 call RAA_misc_fnc_beltSlot_canMoveFrombelt";
						exceptions[] = {};
						statement = "1 call RAA_misc_fnc_beltSlot_doMoveFrombelt";
						icon = "";
						modifierFunction = "[_this, 1] call RAA_misc_fnc_beltSlot_actionModifier";
					};
				};
				
				
				
			};
			
			class ace_field_rations {
			//	exceptions[] = {};	// EXPERIMENTAL Clear exceptions. Default line: exceptions[] = {"isNotInside"};
				
				class RAA_misc_drinkFromBeltItem {
					displayName = "Drink from item on belt";
					condition = "true";
				//	condition = "call RAA_misc_fnc_beltSlot_canDrinkFromBelt";
					exceptions[] = {};
					statement = "";
					icon = QPATHTOF(pics\icon_belt.paa);
					insertChildren = "call RAA_misc_fnc_beltSlot_getDrinkableChildrens";
				//	modifierFunction = "[_this, 1] call RAA_misc_fnc_beltSlot_actionModifier";
				};
				
				/*
				class RAA_misc_drinkFromWaterBladder {
					displayName = "Drink from Water Bladder (%1 L)";
					condition = "1 call RAA_misc_fnc_beltSlot_canMoveFrombelt";
				//    exceptions[] = {};
					statement = "1 call RAA_misc_fnc_beltSlot_doMoveFrombelt";
					icon = "r\misc\addons\RAA_zeus\pics\numbers\trans_2.paa";
					modifierFunction = "[_this, 1] call RAA_misc_fnc_beltSlot_actionModifier";
				};
				
				*/
			};
			
		};
	};
	
	
	
	
	// Shift action to drink/ fill bottles from ammo box
	class ReammoBox_F;
	class B_supplyCrate_F: ReammoBox_F {
		acex_field_rations_offset[] = {0, 0, 0.3};
	};
	
	
	// Motti flag
	class Flag_US_F;
	class RAA_Flag_Motti: Flag_US_F {
		author = "riksuFIN";
		scope = 2;
		scopeCurator = 2;
		displayName = "Flag (Motti)";
	//	model = "\a3\Structures_F\Mil\Flags\Mast_F.p3d";
	//	icon = "iconObject_circle";
		
		class EventHandlers {
		//	init = "(_this select 0) setFlagTexture 'PATHTOEF(RAA_common,pics\Motti_Flag.paa)'";
			init = "(_this select 0) setFlagTexture '\r\RAA\addons\common\pics\Motti_Flag.paa'";	// TODO Figure correct macro for this
		};
	};
	
	
	// Unfinished IED
	class Item_Base_F;
	class RAA_unfinished_ied_item: Item_Base_F {
		scope = 2;
		scopeCurator = 2;
		displayName = "Unfinished IED";
		author = "riksuFIN";
		vehicleClass = "Items";
		editorPreview = QPATHTOF(data\unfin_ied_render.paa);		// TODO: replace this with proper pic
//		model = "\r\misc\addons\RAA_ACEX_Additions\data\can_base.p3d";
		class TransportItems {
			class xx_RAA_unfinished_ied {
				name = "RAA_unfinished_ied";
				count = 1;
			};
		};
	};
	
	
	class RAA_facepaint_item: Item_Base_F {
		scope = 2;
		scopeCurator = 2;
		displayName = "Camouflage Face Paint";
		author = "riksuFIN";
		vehicleClass = "Items";
		editorPreview = QPATHTOF(data\camoFacePaintStick_render.paa);		// TODO: replace this with proper pic
//		model = "\r\misc\addons\RAA_ACEX_Additions\data\can_base.p3d";
		class TransportItems {
			class xx_RAA_facepaint {
				name = "RAA_facepaint";
				count = 1;
			};
		};
	};
	
	
	
	// Create sound object for sound SFX defined in cfgSounds.hpp
	class Sound;
	class RAA_sound_axe_01: Sound {
		scope = 2;
		sound = "RAA_misc_axe_sfx";
		displayName = "[RAA] Chopping tree with Axe";
	};
	class RAA_sound_chainsaw_01: Sound {
		scope = 2;
		sound = "RAA_misc_chainsaw_sfx";
		displayName = "[RAA] Chainsaw";
	};
	
	class RAA_sound_radio_vdvSong: Sound {
		scope = 2;
		sound = "RAA_misc_radio_vdvSong_sfx";
		displayName = "[RAA] VDV Song (Radio Version)";
	};
	
	class RAA_sound_radio_chill: Sound {
		scope = 2;
		sound = "RAA_misc_music_chill_sfx";
		displayName = "[RAA] Music: Chill";
	};
	class RAA_sound_radio_epic: Sound {
		scope = 2;
		sound = "RAA_misc_music_epic_sfx";
		displayName = "[RAA] Music: Epic";
	};
	class RAA_sound_radio_rock: Sound {
		scope = 2;
		sound = "RAA_misc_music_rock_sfx";
		displayName = "[RAA] Music: Rock";
	};
	
	
	
	
	
	
	
	
	// Tree trunk for tree chopping
	class CUP_Akat02S;
	class CUP_kmen_1_buk: CUP_Akat02S {
		
		// Dragging
		ace_dragging_canDrag = 1;  // Can be dragged (0-no, 1-yes)
		ace_dragging_dragPosition[] = {0, 1.5, 0};  // Offset of the model from the body while dragging (same as attachTo) (default: [0, 1.5, 0])
		ace_dragging_dragDirection = 0;  // Model direction while dragging (same as setDir after attachTo) (default: 0)
		
	};
	
	
	
	
	class Items_base_F;
	class Land_FMradio_F: Items_base_F {
		
		ace_dragging_canCarry = 1;  // Can be carried (0-no, 1-yes)
		ace_dragging_carryPosition[] = {0, 1.2, 0};  // Offset of the model from the body while dragging (same as attachTo) (default: [0, 1, 1])
		ace_dragging_carryDirection = 0;  // Model direction while dragging (same as setDir after attachTo) (default: 0)
		ace_cargo_size = 1;	// Can load in vehicles. Why? Why not?
		
		class ACE_Actions {
			class ACE_MainActions {
				displayName = "Interactions";
				selection = "";
				distance = 2;
				condition = "true";
				
				class GVAR(radio_off) {
					displayName = "Turn radio on";
					condition = QUOTE(alive _target && !(_target getVariable [QQGVAR(radioPower), false]));
					exceptions[] = {};
				//	statement = QUOTE([_this, 1] call FUNC(handleRadioAction));
					statement = QUOTE([_this, 1] remoteExec [QQFUNC(handleRadioAction), 2]);
				//	modifierFunction = "";
				//	icon = "\z\dance.paa";
					distance = 3;
				};
				
				class GVAR(radio_on) {
					displayName = "Turn radio off";
					condition = QUOTE(alive _target && (_target getVariable [QQGVAR(radioPower), false]));
					exceptions[] = {};
				//	statement = QUOTE([_this, 0] call FUNC(handleRadioAction));
					statement = QUOTE([_this, 0] remoteExec [QQFUNC(handleRadioAction), 2]);
				//	modifierFunction = "";
				//	icon = "\z\dance.paa";
					distance = 3;
					
					class GVAR(radio_change_station) {
						displayName = "Switch Station";
						condition = "true";
						exceptions[] = {};
					//	statement = QUOTE([_this, 2] call FUNC(handleRadioAction));
						statement = QUOTE([_this, 2] remoteExec [QQFUNC(handleRadioAction), 2]);
					//	modifierFunction = "";
					//	icon = "\z\dance.paa";
						distance = 3;
					};
					
				};
			};
		};
	};
	
	
	
	
	
	
	
	
	
	
};

