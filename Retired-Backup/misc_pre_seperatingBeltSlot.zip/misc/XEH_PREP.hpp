PREP(facepaint);
PREP(facepaint_canApply);
PREP(showMessage);
PREP(canChopDownTree);
PREP(action_chopDownTree);
PREP(DoChopDownTree);
PREP(handleAIInit);
PREP(handleRadioAction);
PREP(windAffectWalkingLoop);

PREP(beltSlot_onInventoryOpened);
PREP(beltSlot_doMoveToBelt);
PREP(beltSlot_doMoveFrombelt);
PREP(beltSlot_getChildrens);
PREP(beltSlot_canMoveFrombelt);
PREP(beltSlot_canMoveToBelt);
PREP(beltSlot_actionModifier);
PREP(beltSlot_canDrinkFromBelt);
PREP(beltSlot_doDrinkFromBelt);
PREP(beltSlot_getDrinkableChildrens);
PREP(beltSlot_onMountingVehicle);
PREP(beltSlot_hasItem);
PREP(beltSlot_getItems);
PREP(beltSlot_deleteFromBelt);
PREP(beltSlot_doReplaceItem);

PREP(damageableItems_onHit);
PREP(damageableItems_doDamage);
PREP(damageableItems_headgear);
PREP(damageableItems_deleteItem);


