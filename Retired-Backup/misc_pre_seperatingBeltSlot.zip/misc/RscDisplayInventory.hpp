class RscText;
class RscPicture;
class RscFrame;
class RscButton;
class RscListbox;
class RscActiveText;

class RscDisplayInventory {
	
	class controls {
		
		
		/*
		class RAA_beltSlot_text: RscText {
			idc = 1089;
			text = "Weight: %1 kg"; //--- ToDo: Localize;
			x = 0.2525 * safezoneW + safezoneX;
			y = 0.962 * safezoneH + safezoneY;
			w = 0.0876563 * safezoneW;
			h = 0.011 * safezoneH;
			tooltip = "Use ACE action menu to change these"; //--- ToDo: Localize;
		};
		*/
		

		// [0,0,0,0.8]
		// [1,1,1,0.1]
		/*
		class RAA_beltSlot_1: RscPicture {
			idc = 1288;
			text = "";
			x = 0.2525 * safezoneW + safezoneX;
			y = 0.896 * safezoneH + safezoneY;
			w = 0.04125 * safezoneW;
			h = 0.055 * safezoneH;
			colorBackground[] = {1,1,1,0.1};
			tooltip = "Use ACE Action Menu to swap these items"; //--- ToDo: Localize;
		};
		class RAA_beltSlot_2: RscPicture {
			idc = 1289;
			text = "";
			x = 0.298906 * safezoneW + safezoneX;
			y = 0.896 * safezoneH + safezoneY;
			w = 0.04125 * safezoneW;
			h = 0.055 * safezoneH;
			colorBackground[] = {1,1,1,0.1};
			tooltip = "Use ACE Action Menu to swap these items"; //--- ToDo: Localize;
		};
		*/
		
		class RAA_beltSlot_slot1: RscListbox {
			idc = 1288;
		//	text = "";
			x = 0.2525 * safezoneW + safezoneX;
			y = 0.896 * safezoneH + safezoneY;
			w = 0.154687 * safezoneW;
			h = 0.044 * safezoneH;
			colorBackground[] = {1,1,1,0.1};
			colorSelectBackground[] = {1,1,1,0.1};
			rowHeight = "1.75 * (((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 1)";
			tooltip = "Use ACE Action Menu to swap these items"; //--- ToDo: Localize;
		//	onButtonClick = "systemChat str _this";
			onLBDrop = QUOTE([nil, player, _this select 4 select 0 select 2, false, 0, _this select 3] call FUNC(beltSlot_doMoveToBelt));
		//	onLBDrag = "systemChat str _this";
			canDrag = 1;
		};
		
	//	class SlotPrimary;
	//	class RAA_beltSlot_testButton2: SlotPrimary {
		class RAA_beltSlot_slot2: RscListbox {
			idc = 1289;
		//	text = "";
			x = 0.4175 * safezoneW + safezoneX;
			y = 0.896 * safezoneH + safezoneY;
			w = 0.154687 * safezoneW;
			h = 0.044 * safezoneH;
			colorBackground[] = {1,1,1,0.1};
			rowHeight = "1.75 * (((((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 1)";
			tooltip = "Use ACE Action Menu to swap these items"; //--- ToDo: Localize;
		//	onButtonClick = "systemChat str _this";
			onLBDrop = QUOTE([nil, player, _this select 4 select 0 select 2, false, 1, _this select 3] call FUNC(beltSlot_doMoveToBelt));
		//	onLBDrag = "systemChat str _this";
			canDrag = 1;
		//	style = "0x30 + 0x800";
		};
		
		
		
		
		
		
		class GroundContainer: RscListBox {
		//	onLBDrop = QUOTE([-1, player, 9, _this select 3] call FUNC(beltSlot_doMoveFrombelt));
			onLBDrop = QUOTE(if (_this select 3 in [1288, 1289]) then {[-1, player, 9, _this select 3] call FUNC(beltSlot_doMoveFrombelt)});
		};
		
	//	class GroundContainer;
		class UniformContainer: GroundContainer {		// idc = 633;		Select 3
			onLBDrop = QUOTE(if (_this select 3 in [1288, 1289]) then {[-1, player, 0, _this select 3] call FUNC(beltSlot_doMoveFrombelt)});
		};
		
		class VestContainer: UniformContainer {		// idc = 638;
			onLBDrop = QUOTE(if (_this select 3 in [1288, 1289]) then {[-1, player, 1, _this select 3] call FUNC(beltSlot_doMoveFrombelt)});
		};
		
		class BackpackContainer: UniformContainer {		// idc = 619;
			onLBDrop = QUOTE(if (_this select 3 in [1288, 1289]) then {[-1, player, 2, _this select 3] call FUNC(beltSlot_doMoveFrombelt)});
		};
		
		
		
		
		
		/*
		class SlotPrimary;
		class SlotBelt1: SlotPrimary {
			idc = 6288;
			colorText[] = {0,0,0,0.5};
			x = "safeZoneX + safeZoneW * 0.3";
			y = "safeZoneY + safeZoneH * 0.86";
			w = "safeZoneW * 0.035";
			h = "safeZoneH * 0.04888889";
		//	colorBackground[] = {1,1,1,0.1};
			
		};
		
		class SlotBelt2: SlotBelt1 {
			idc = 6289;
			colorText[] = {0,0,0,0.5};
			x = "safeZoneX + safeZoneW * 0.35";
			y = "safeZoneY + safeZoneH * 0.86";
			w = "safeZoneW * 0.035";
			h = "safeZoneH * 0.04888889";
		//	colorBackground[] = {1,1,1,0.1};
			
		};
		*/
	};
	
	
	class controlsBackground {
		/*
		class BI_Background_Base;
		class BI_Frame_Base;
		class RAA_Background_belt1: BI_Background_Base {
			idc = 88881;
			x = "safeZoneX + safeZoneW * 0.3";
			y = "safeZoneY + safeZoneH * 0.86";
			w = "safeZoneW * 0.035";
			h = "safeZoneH * 0.04888889";
		};
		class RAA_Background_belt2: BI_Frame_Base {
		idc = 88882;
		x = "safeZoneX + safeZoneW * 0.35";
		y = "safeZoneY + safeZoneH * 0.86";
		w = "safeZoneW * 0.035";
		h = "safeZoneH * 0.04888889";
		};
		*/
		
		
		class RAA_beltSlot_backGround: RscText
		{
			idc = 1089;
			x = 0.247344 * safezoneW + safezoneX;
			y = 0.874 * safezoneH + safezoneY;
			w = 0.33 * safezoneW;
			h = 0.077 * safezoneH;
			colorBackground[] = {0,0,0,0.8};
		};
		
		class RAA_beltSlot_frame: RscFrame
		{
			idc = 1889;
			text = "Items on belt"; //--- ToDo: Localize;
			x = 0.247344 * safezoneW + safezoneX;
			y = 0.874 * safezoneH + safezoneY;
			w = 0.33 * safezoneW;
			h = 0.077 * safezoneH;
			colorBackground[] = {0.05,0.05,0.05,0.7};
			colorFrame[] = {1,1,1,1};
			SizeEx = "(			(			(			((safezoneW / safezoneH) min 1.2) / 1.2) / 25) * 1)";
			
		//	colorBackground[] = {1,0,1,1};
		//	sizeEx = 1 * GUI_GRID_H;
		};
		
		
		
		
		
	};
};





