#include "script_component.hpp"

class CfgPatches 
{
	class ADDON
	{
		name = COMPONENT_NAME;
		author = "riksuFIN";
		requiredVersion = REQUIRED_VERSION;
		VERSION_CONFIG;
		units[] = {	// Classes from cfgVehicles
			"RAA_unfinished_ied_item",
			"RAA_facepaint_item",
			"RAA_sound_axe_01"
		};
		weapons[] = {	// Classes from cfgWeapons
			"RAA_facepaint"
		};

		requiredAddons[] = {
			"A3_Data_F_Tank_Loadorder",
			"RAA_common",
			"cba_xeh",
			"ace_interact_menu",
			"zen_dialog",
			"ace_overheating",
			"CUP_Editor_Plants_Config",	// For fallen tree used for delimbed trees
			"rhsusf_c_weapons"
		};
		
		
	};
};

#include "CfgEventHandlers.hpp"

#include "cfgMoves.hpp"
#include "cfgSounds.hpp"
#include "cfgVehicles.hpp"
#include "cfgWeapons.hpp"
#include "RscDisplayInventory.hpp"	// Add belt slots to inventory IGUI


/*	Moved to CBA file structure
//	Add CBA Settings
class Extended_PreInit_EventHandlers {
    class RAA_misc_pre_init_event {
        init = "call compile preprocessFileLineNumbers '\r\misc\addons\RAA_misc\CBA_Settings.sqf'";
    };
};


class Extended_PostInit_EventHandlers {
    class RAA_misc_post_init_event {
        init = "call compile preprocessFileLineNumbers '\r\misc\addons\RAA_misc\XEH_postInit.sqf'";
    };
};
*/



// This is used to update beltSlot pics in inventory
class Extended_InventoryOpened_EventHandlers {
	class CAManBase
	{
		ADDON = "call RAA_misc_fnc_beltSlot_onInventoryOpened";
	};
};




