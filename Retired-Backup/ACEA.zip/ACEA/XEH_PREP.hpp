//PREP(empty);
PREP(onMenuOpen_loadoutOverview);
PREP(arsenal_overview_update);
PREP(arsenal_overview_getInventoryItems);
PREP(arsenal_description);
PREP(defib_canUse);
PREP(propofol);
PREP(propofol_local);

PREP(treatmentFeedback_helper);
PREP(treatmentFeedback_patient);

PREP(takeDetonator);
PREP(takeDetonator_getChildren);

//PREP(getConsumeableItem);

// There's nothing more annoying than two functions of same feature named slightly differently, right?   Yeah, so I though... Too late to change it thou :(
PREP(tear_fabric);
PREP(tearFabric_start);

PREP(forceFeed_canUse);