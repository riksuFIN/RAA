#define COMPONENT ACEA
#define COMPONENT_BEAUTIFIED ACE Additions
#include "\r\RAA\addons\common\script_mod.hpp"

 #define DEBUG_MODE_FULL
// #define DISABLE_COMPILE_CACHE
// #define ENABLE_PERFORMANCE_COUNTERS

#ifdef DEBUG_ENABLED_ACE_additions
    #define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_ACE_additions
    #define DEBUG_SETTINGS DEBUG_SETTINGS_BLANK
#endif

#include "\z\ace\addons\main\script_macros.hpp"	// Do not touch this

#define COMPNAME "ACEA"