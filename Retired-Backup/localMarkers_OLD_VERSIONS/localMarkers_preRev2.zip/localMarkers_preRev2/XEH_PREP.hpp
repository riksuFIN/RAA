PREP(markerCreated);
PREP(markerDeleted);
PREP(madeByPlayer);
PREP(copyMap_start);
PREP(copyMap);



