#define COMPONENT localMarkers
#define COMPONENT_BEAUTIFIED Local Markers
#include "\r\RAA\addons\common\script_mod.hpp"

 #define DEBUG_MODE_FULL
// #define DISABLE_COMPILE_CACHE
// #define ENABLE_PERFORMANCE_COUNTERS

#ifdef DEBUG_ENABLED_LOCALMARKERS
    #define DEBUG_MODE_FULL
#endif

#ifdef DEBUG_SETTINGS_LOCALMARKERS
    #define DEBUG_SETTINGS DEBUG_SETTINGS_LOCALMARKERS
#endif

#include "\z\ace\addons\main\script_macros.hpp"

// Used for debug messages
#define COMPNAME "LocalMarkers"