class CfgWeapons {
	
	
	THIS FILE IS DISABLED IN CONFIG.CPP!
	
	
	
	
};