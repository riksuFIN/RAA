////////////////////////////////////////////////////////////////////
//DeRap: config.bin
//Produced from mikero's Dos Tools Dll version 9.10
//https://mikero.bytex.digital/Downloads
//'now' is Wed Apr 17 18:33:34 2024 : 'file' last modified on Mon Oct 30 19:54:41 2023
////////////////////////////////////////////////////////////////////

#define _ARMA_

class CfgPatches
{
	class RAA_localMarkers
	{
		name = "Motti Misc - Local Markers";
		author = "riksuFIN";
		requiredVersion = 2.06;
		version = 1.34;
		versionStr = "1.34.1.0";
		versionAr[] = {1,34,1,0};
		units[] = {};
		weapons[] = {};
		requiredAddons[] = {"A3_Data_F_Tank_Loadorder","RAA_common","cba_xeh","ace_interact_menu"};
	};
};
class Extended_PreStart_EventHandlers
{
	class RAA_localMarkers
	{
		init = "call compileScript ['\r\RAA\addons\localMarkers\XEH_preStart.sqf']";
	};
};
class Extended_PreInit_EventHandlers
{
	class RAA_localMarkers
	{
		init = "call compileScript ['\r\RAA\addons\localMarkers\XEH_preInit.sqf']";
	};
};
class Extended_PostInit_EventHandlers
{
	class RAA_localMarkers
	{
		init = "call compileScript ['\r\RAA\addons\localMarkers\XEH_postInit.sqf']";
	};
};
class CfgVehicles
{
	class Man;
	class CAManBase: Man
	{
		class ACE_Actions
		{
			class ACE_MainActions
			{
				class RAA_localMarkers_copy
				{
					displayName = "Copy Map Markers";
					condition = "RAA_localMarkers_enabled && isPlayer _target";
					statement = "[{[_this select 0] call RAA_localMarkers_fnc_copyMap_start}, [_target]] call CBA_fnc_execNextFrame;";
					icon = "\r\RAA\addons\localMarkers\pics\icon_map";
				};
			};
		};
	};
};
