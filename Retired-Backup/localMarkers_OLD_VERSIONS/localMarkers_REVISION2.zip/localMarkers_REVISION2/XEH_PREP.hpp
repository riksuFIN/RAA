PREP(copyMap_requester_part1);
PREP(copyMap_requster_part2);

PREP(copyMap_target_part1);
PREP(copyMap_target_part2);

PREP(madeByPlayer);
PREP(marker_stripTag);
PREP(markerCreated);
PREP(markerDeleted);
PREP(onJIP);


